/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package rpgcorp.zuul;

/**
 *
 * @author renan
 */
public class Programa {

	public static void main(String[] args) {
		Jogo jogo = new Jogo();

		jogo.jogar();
	
        }

}
